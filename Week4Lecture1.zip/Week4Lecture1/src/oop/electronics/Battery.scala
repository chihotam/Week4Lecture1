package oop.electronics

class Battery(var charge: Int) {

}
